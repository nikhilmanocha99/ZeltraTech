import axios from 'axios';

const API_URL = 'http://localhost:8000/api/';

const api = axios.create({
  baseURL: API_URL,
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = 'Bearer ' + token;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      try {
        const refreshResponse = await refreshToken();
        localStorage.setItem('token', refreshResponse.data.access);
        api.defaults.headers['Authorization'] = 'Bearer ' + refreshResponse.data.access;
        return api(originalRequest);
      } catch (refreshError) {
        // Refresh token is also expired
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
        window.location = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export const login = (username, password) => api.post('token/', { username, password });
export const register = (username, email, password) => api.post('register/', { username, email, password });
export const refreshToken = () => api.post('token/refresh/', { refresh: localStorage.getItem('refreshToken') });
export const getUsers = () => api.get('users/');
export const sendInterest = (senderId, receiverId) => api.post('interests/', { sender: senderId, receiver: receiverId, status: 'pending' });
export const getInterests = (userId) => api.get(`interests/?receiver=${userId}`);
export const acceptInterest = (interestId) => api.post(`interests/${interestId}/accept/`);
export const rejectInterest = (interestId) => api.post(`interests/${interestId}/reject/`);
export const getMessages = (userId1, userId2) => api.get(`messages/?sender=${userId1}&receiver=${userId2}`);
export const sendMessage = (senderId, receiverId, content) => api.post('messages/', { sender: senderId, receiver: receiverId, content });

export default api;