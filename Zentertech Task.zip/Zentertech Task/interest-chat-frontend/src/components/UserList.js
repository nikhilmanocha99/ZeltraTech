import React, { useState, useEffect } from 'react';
import { List, ListItem, ListItemText, Button, Typography, Container } from '@material-ui/core';
import { getUsers, sendInterest } from '../services/api';
//import { useNavigate } from 'react-router-dom';

function UserList() {
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');
  //const navigate = useNavigate();

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await getUsers();
      setUsers(response.data);
    } catch (error) {
      setError('Failed to fetch users. Please try again.');
      console.error('Failed to fetch users:', error);
    }
  };

  const handleSendInterest = async (receiverId) => {
    try {
      const senderId = localStorage.getItem('userId'); // Assuming you store the user's ID in localStorage
      await sendInterest(senderId, receiverId);
      alert('Interest sent successfully!');
    } catch (error) {
      setError('Failed to send interest. Please try again.');
      console.error('Failed to send interest:', error);
    }
  };

  return (
    <Container>
      <Typography variant="h4">User List</Typography>
      {error && <Typography color="error">{error}</Typography>}
      <List>
        {users.map((user) => (
          <ListItem key={user.id}>
            <ListItemText primary={user.username} secondary={user.email} />
            <Button onClick={() => handleSendInterest(user.id)} variant="contained" color="primary">
              Send Interest
            </Button>
          </ListItem>
        ))}
      </List>
    </Container>
  );
}

export default UserList;