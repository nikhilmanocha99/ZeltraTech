import React, { useState, useEffect } from 'react';
import { List, ListItem, ListItemText, Button, Typography, Container } from '@material-ui/core';
import { getInterests, acceptInterest, rejectInterest } from '../services/api';

function InterestList() {
  const [interests, setInterests] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchInterests();
  }, []);

  const fetchInterests = async () => {
    try {
      const userId = localStorage.getItem('userId'); // Assuming you store the user's ID in localStorage
      const response = await getInterests(userId);
      setInterests(response.data);
    } catch (error) {
      setError('Failed to fetch interests. Please try again.');
      console.error('Failed to fetch interests:', error);
    }
  };

  const handleAcceptInterest = async (interestId) => {
    try {
      await acceptInterest(interestId);
      fetchInterests(); // Refresh the list
    } catch (error) {
      setError('Failed to accept interest. Please try again.');
      console.error('Failed to accept interest:', error);
    }
  };

  const handleRejectInterest = async (interestId) => {
    try {
      await rejectInterest(interestId);
      fetchInterests(); // Refresh the list
    } catch (error) {
      setError('Failed to reject interest. Please try again.');
      console.error('Failed to reject interest:', error);
    }
  };

  return (
    <Container>
      <Typography variant="h4">Interest List</Typography>
      {error && <Typography color="error">{error}</Typography>}
      <List>
        {interests.map((interest) => (
          <ListItem key={interest.id}>
            <ListItemText primary={`From: ${interest.sender.username}`} secondary={`Status: ${interest.status}`} />
            {interest.status === 'pending' && (
              <>
                <Button onClick={() => handleAcceptInterest(interest.id)} variant="contained" color="primary">
                  Accept
                </Button>
                <Button onClick={() => handleRejectInterest(interest.id)} variant="contained" color="secondary">
                  Reject
                </Button>
              </>
            )}
          </ListItem>
        ))}
      </List>
    </Container>
  );
}

export default InterestList;