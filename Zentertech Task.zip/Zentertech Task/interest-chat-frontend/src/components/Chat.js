import React, { useState, useEffect, useCallback } from 'react';
import { TextField, Button, Typography, Container, List, ListItem, ListItemText } from '@material-ui/core';
import { getMessages, sendMessage } from '../services/api';
import { useParams } from 'react-router-dom';

function Chat() {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [error, setError] = useState('');
  const { userId } = useParams(); // Assuming the URL is like /chat/:userId

  useEffect(() => {
    const intervalId = setInterval(fetchMessages, 5000);
    fetchMessages();
    return () => clearInterval(intervalId);
  }, [userId, fetchMessages]);


  const fetchMessages = useCallback(async () => {
    try {
      const currentUserId = localStorage.getItem('userId');
      const response = await getMessages(currentUserId, userId);
      setMessages(response.data);
    } catch (error) {
      setError('Failed to fetch messages. Please try again.');
      console.error('Failed to fetch messages:', error);
    }
  }, [userId]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    try {
      const senderId = localStorage.getItem('userId');
      await sendMessage(senderId, userId, newMessage);
      setNewMessage('');
      fetchMessages(); // Refresh the messages
    } catch (error) {
      setError('Failed to send message. Please try again.');
      console.error('Failed to send message:', error);
    }
  };

  return (
    <Container>
      <Typography variant="h4">Chat</Typography>
      {error && <Typography color="error">{error}</Typography>}
      <List>
        {messages.map((message) => (
          <ListItem key={message.id}>
            <ListItemText 
              primary={message.content} 
              secondary={`From: ${message.sender.username} at ${new Date(message.timestamp).toLocaleString()}`} 
            />
          </ListItem>
        ))}
      </List>
      <form onSubmit={handleSendMessage}>
        <TextField
          label="New Message"
          fullWidth
          margin="normal"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
        />
        <Button type="submit" variant="contained" color="primary">
          Send
        </Button>
      </form>
    </Container>
  );
}

export default Chat;