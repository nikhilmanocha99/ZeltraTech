import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import UserList from './components/UserList';
import InterestList from './components/InterestList';
import Chat from './components/Chat';
import PrivateRoute from './components/PrivateRoute';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/users" component={UserList} />
          <Route path="/interests" component={InterestList} />
          <Route path="/chat/:userId" component={Chat} />
          <Route path="/" exact component={Login} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
