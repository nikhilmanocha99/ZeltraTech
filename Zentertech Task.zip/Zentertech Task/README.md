
## POSTMAN Documentation Link
### https://documenter.getpostman.com/view/15244754/2sAXjGatHF


# ZentraTech Developer Job Test 

This project is a full-stack web application that allows users to send interest messages to other users, accept or reject interests, and chat with each other.

## Prerequisites
    Python 3.8+
    Node.js 14+
    yarn
    npm6+

## Backend Setup

    Clone The repository. 
    
    Set up Virtual Environment 

        python -m venv {virtual_env_name}
        source venv/bin/activate  # On Windows, use: venv\Scripts\activate
    
    Install Backend Dependencies
        cd interest_chat_project
        pip install -r requirements.txt

    Run Migrations
        python manage.py makemigrations
        python manage.py migrate
    
    Run server
        python manage.py runserver

## Frontend Setup

    Navigate to Frontend directory
        cd interest-chat-frontend

    Install frontend dependencies
        npm install
    
    Run Development Server
        npm start


## Running Application
    The backend API will be available at `http://localhost:8000/api/`
    The frontend will be available at `http://localhost:3000`

## Design Choices

- Django was chosen for the backend due to its robust ORM and built-in authentication system.
- Django Rest Framework was used to quickly build a RESTful API.
- React was chosen for the frontend for its component-based architecture and large ecosystem.
- JWT authentication was implemented for secure, stateless authentication between frontend and backend.

## Assumptions

- Users can send interest messages to any other user.
- Once an interest is accepted, both users can chat with each other.
- Real-time functionality is not implemented due to time constraints.

