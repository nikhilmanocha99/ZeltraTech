from django.test import TestCase
from django.contrib.auth.models import User
from .models import Interest, Message

class InterestModelTest(TestCase):
    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='pass1')
        self.user2 = User.objects.create_user(username='user2', password='pass2')

    def test_interest_creation(self):
        interest = Interest.objects.create(sender=self.user1, receiver=self.user2, status='pending')
        self.assertEqual(interest.sender, self.user1)
        self.assertEqual(interest.receiver, self.user2)
        self.assertEqual(interest.status, 'pending')
